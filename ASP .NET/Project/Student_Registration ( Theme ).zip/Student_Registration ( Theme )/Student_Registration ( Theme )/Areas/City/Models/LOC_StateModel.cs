﻿namespace Student_Registration___Theme__.Areas.City.Models
{
    public class LOC_StateModel
    {
        public int StateID { get; set; }
        public string StateName { get; set; } = string.Empty;
        public int CountryID { get; set; }
    }
}
