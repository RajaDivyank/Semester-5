﻿namespace Student_Registration___Theme__.Areas.City.Models
{
    public class LOC_CountryModel
    {
        public int CountryID { get; set; }
        public string CountryName { get; set; } = string.Empty;
    }
}
