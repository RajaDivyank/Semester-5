﻿namespace Student_Registration.Areas.State.Models
{
    public class LOC_CountryModel
    {
        public int CountryId { get; set; }
        public string CountryName { get; set; } = string.Empty;
    }
}
